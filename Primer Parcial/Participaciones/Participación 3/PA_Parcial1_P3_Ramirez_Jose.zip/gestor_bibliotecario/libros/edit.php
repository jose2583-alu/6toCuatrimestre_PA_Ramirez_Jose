<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    // Aquí va el código para obtener el libro usando una consulta preparada
    if($id > 0){
        $stmt = $conn->prepare("SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles FROM libros WHERE id = ?"); // Nuestra consulta preparada es un SELECT en el cual obtendremos los datos según el ID que recibimos por la URL. Recordemos que el signo de interrogación (?) es un marcador de posición para el valor que se pasará posteriormente. ¿Por qué primero hacemos un SELECT?
        $stmt->bind_param("i", $id); // Lo que hacemos es decirle a la consulta que el marcador de posición es un número entero (i) y que el valor que pasará es el de la variable $id.
        $stmt->execute(); // Ejecutamos la consulta preparada.
        $resultado = $stmt->get_result(); // Obtenemos el resultado de la consulta
        $libro = $resultado->fetch_assoc(); // Obtenemos la fila del resultado como un array asociativo y lo almacenamos en la variable $libro.
        $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
    }else{
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
        // Aquí va el código para obtener los autores asignados al libro usando una consulta preparada
    if($id > 0){
        $stmt = $conn->prepare("SELECT a.id, a.nombre FROM autores a INNER JOIN libro_autor la ON a.id = la.id_autor WHERE la.id_libro = ?"); // 
        $stmt->bind_param("i", $id); // Lo que hacemos es decirle a la consulta que el marcador de posición es un número entero (i) y que el valor que pasará es el de la variable $id.
        $stmt->execute(); // Ejecutamos la consulta preparada.
        $resultado = $stmt->get_result(); // Obtenemos el resultado de la consulta
        $autor = $resultado->fetch_assoc(); // Obtenemos la fila del resultado como un array asociativo y lo almacenamos en la variable $autor.
        $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
    }else{
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
    // Aquí va el código para obtener todas las categorías usando una consulta preparada
        $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias "); // Nuestra consulta preparada es un SELECT en el cual obtendremos los datos según el ID que recibimos por la URL. Recordemos que el signo de interrogación (?) es un marcador de posición para el valor que se pasará posteriormente. ¿Por qué primero hacemos un SELECT?
        $stmt->execute(); // Ejecutamos la consulta preparada.
        $categorias = $stmt->get_result(); // Obtenemos la fila del resultado como un array asociativo y lo almacenamos en la variable $categorias.
        $stmt->close(); // Cerramos la consulta preparada para liberar recursos.

    // Aquí va el código para obtener todos los autores usando una consulta preparada
    $stmt = $conn->prepare("SELECT id, nombre, apellido FROM autores "); // Nuestra consulta preparada es un SELECT en el cual obtendremos los datos según el ID que recibimos por la URL. Recordemos que el signo de interrogación (?) es un marcador de posición para el valor que se pasará posteriormente. ¿Por qué primero hacemos un SELECT?
        $stmt->execute(); // Ejecutamos la consulta preparada.
        $autores = $stmt->get_result(); // Obtenemos la fila del resultado como un array asociativo y lo almacenamos en la variable $autores.
        $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
    $conn->close(); // Cerramos la conexión a la base de datos para liberar recursos
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-book-open"></i> Editar Libro</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $libro["id"] ?? $id ?>">

        <div class="form-group">
            <label><i class="fas fa-book"></i> Título</label>
            <input type="text" name="titulo" value="<?= htmlspecialchars($libro["titulo"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-barcode"></i> ISBN</label>
            <input type="text" name="isbn" value="<?= htmlspecialchars($libro["isbn"] ?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Año de Publicación</label>
            <input type="number" name="anio_publicacion" value="<?= $libro["anio_publicacion"] ?? "" ?>" min="1000" max="<?= date('Y') ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-building"></i> Editorial</label>
            <input type="text" name="editorial" value="<?= htmlspecialchars($libro["editorial"] ?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-cubes"></i> Cantidad</label>
            <input type="number" name="cantidad" value="<?= $libro["cantidad"] ?? 0 ?>" min="0">
        </div>

        <div class="form-group">
            <label><i class="fas fa-check-circle"></i> Disponibles</label>
            <input type="number" name="disponibles" value="<?= $libro["disponibles"] ?? 0 ?>" min="0">
        </div>

        <div class="form-group">
            <label><i class="fas fa-tag"></i> Categoría</label>
            <select name="id_categoria" required>
                <option value="">-- Selecciona una categoría --</option>
                <?php
                    // Aquí va el código para mostrar las categorías en el <select>
                    while($row = $categorias->fetch_assoc()) { // Si el id de la opción actual es igual al que tiene asignado el registro principal...
                  $selected = ($row['id'] == $libro['id_categoria']) ? 'selected' : '';
    echo "<option value='" . $row['id'] . "' $selected>" . htmlspecialchars($row['nombre']) . "</option>";
}
                ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Autor(es)</label>
            <select name="id_autores[]" multiple required>
                <?php
                    // Aquí va el código para mostrar los autores en el <select>
                    while($row = $autores->fetch_assoc()) { // Si el id de la opción actual está en el array de autores asignados al libro...
                     $selected = ($row['id'] == $autor['id']) ? 'selected' : '';
                     echo "<option value='" . $row['id'] . "' $selected>" . htmlspecialchars($row['nombre']) . "</option>";
                    }
                ?>
            </select>
            <small>Mantén Ctrl (o Cmd) para seleccionar varios autores</small>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
