<?php
    require_once "../config/connection.php";
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-book"></i> Libros</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Libro
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Título</th>
                <th>ISBN</th>
                <th>Categoría</th>
                <th>Año</th>
                <th>Editorial</th>
                <th>Cantidad</th>
                <th>Disponibles</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
                // Aquí va el código para el select que mostrará los libros
                $stmt = $conn->prepare("SELECT l.id, l.titulo, l.ISBN, l.anio_publicacion, l.editorial, l.cantidad, l.disponibles, c.nombre AS categoria FROM libros l INNER JOIN categorias c ON l.id_categoria = c.id"); // se prepara la consulta SQL para obtener libros, incluyendo un JOIN para obtener el nombre de la categoría asociada a cada libro. La consulta selecciona el ID, título, ISBN, año de publicación, editorial, cantidad total, cantidad disponible y el nombre de la categoría.
                $stmt->execute(); // En esta linea, la función execute() ejecutamos la consulta que previamente preparamos.
                $resultado = $stmt->get_result(); // En la variable resultado, almacenamos el resultado de la consulta que ejecutamos. Hacemos utilizando la función o método get_result() el cual nos devuelve un objeto que representa el conjunto de resultados obtenido de la consulta.
                while($row = $resultado->fetch_assoc()){ // En esta línea de código, iniciamos un ciclo while para recorrer cada fila del resultado obtenido. Utilizamos una variable llamada $row para almacenar cada fila, y por medio de la función fetch_assoc() obtenemos cada fila como si fuera un array asociativo, lo cual permitirá que accedamos a los valores mediante clave-valor.
                    echo "<tr>"; // La etiqueta <tr> se utiliza para definir una fila en una tabla HTML.
                    echo "<td>" . htmlspecialchars($row["id"]) . "</td>"; // Utilizamos la etiqueta <td> para definir una celda dentro de la fila. En ella mostraremos el ID del libro y usaremos htmlspecialchars() para sanitizar el valor y evitar posibles inyecciones SQL.
                    echo "<td>" . htmlspecialchars($row["titulo"]) . "</td>";  // Insertamos el título.
                    echo "<td>" . htmlspecialchars($row["ISBN"]) . "</td>";  // Insertamos el ISBN.
                    echo "<td>" . htmlspecialchars($row["categoria"]) . "</td>";  // Insertamos el nombre de la categoría.
                    echo "<td>" . htmlspecialchars($row["anio_publicacion"]) . "</td>";  // Insertamos el año.
                    echo "<td>" . htmlspecialchars($row["editorial"]) . "</td>";  // Insertamos el nombre de la editorial.
                    echo "<td>" . htmlspecialchars($row["cantidad"]) . "</td>";  // mostramos la cantidad total de libros.
                    echo "<td>" . htmlspecialchars($row["disponibles"]) . "</td>";  // mostramos la cantidad disponible.
                    echo "<td>"; // Abrimos una nueva celda para colocar los botones de acción (editar y eliminar).
                    echo "<a href='edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Editar</a>";
                    echo "<a href='delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger'><i class='fas fa-trash'></i> Eliminar</a>";
                    echo "</td>";
                    echo "</tr>"; // Cerramos la etiqueta <tr> para finalizar la fila.
                }
                $stmt->close(); // Cerramos la consulta preparada para liberar recursos.
                $conn->close(); // Cerramos la conexión a la base de datos para liberar recursos.
            ?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>
