// 1. Seleccionamos el botón por su ID
const miBoton = document.getElementById('btn-cargar');
const contenedor = document.getElementById('contenedor-perros');

// 2. Le agregamos el escuchador de eventos

miBoton.addEventListener('click', async function() {
    
    // El bloque try/catch sirve para atrapar errores si el internet falla
    try {
        // 1. Hacemos la petición a la URL de la API y esperamos la respuesta
        const respuesta = await fetch('https://dog.ceo/api/breeds/image/random');
        
        // 2. Convertimos esa respuesta cruda en un objeto JSON de JavaScript
        const datos = await respuesta.json();

        // 1. Rompemos la URL por sus diagonales
const partesUrl = datos.message.split('/');

// 2. Extraemos la posición donde viene la raza
const razaExtraida = partesUrl[4];
        
        // 3. Imprimimos los datos en la consola para ver qué nos mandó la API
        console.log(datos);
        // Definimos la estructura HTML de la tarjeta de forma dinámica
const tarjetaHTML = `
    <div class="tarjeta-perro">
        <img src="${datos.message}" alt="Perrito Aleatorio" style="max-width: 100%;">
        <p><strong>Raza:</strong> ${razaExtraida}</p>
    </div>
`;
// Insertamos la tarjeta reemplazando o añadiendo contenido en el contenedor
contenedor.innerHTML = tarjetaHTML;

    } catch (error) {
        console.error("Hubo un error al obtener los datos:", error);
    }
});