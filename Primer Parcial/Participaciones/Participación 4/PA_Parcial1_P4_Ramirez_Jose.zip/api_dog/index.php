<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galería de Perritos</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Galería de Perritos</h1>

    <button id="btn-cargar">Actualizar Imágenes</button>

    <div id="contenedor-perros"></div>

    <script src="script.js"></script>
</body>
</html>