// La palabra clave 'async' siempre va antes de la función
async function miFuncionAsincrona() {
    try {
        // 1. Hacemos la petición al servidor externo y esperamos la respuesta
        const respuesta = await fetch("https://api.thecatapi.com/v1/images/search?limit=10");

        // 2. Convertimos la respuesta cruda del servidor en un formato JSON legible
        const datos = await respuesta.json();

        // 3. Imprimimos en consola para verificar qué nos devolvió
        console.log(datos);

        // A) Seleccionamos el contenedor del HTML por su ID
        const miContenedor = document.getElementById("contenedor-gatos");

        // Opcional: limpiamos el contenedor para reemplazar los gatos anteriores
        miContenedor.innerHTML = "";

        // B) Recorremos la lista de elementos que nos dio la API
        datos.forEach(elemento => {
            // C) Creamos un fragmento de HTML en texto con los datos dinámicos
            // Nota: Usamos "elemento.url" porque es donde la API guarda la imagen
            const tarjetaHTML = `
                <div class="tarjeta-gato">
                    <img src="${elemento.url}" alt="Gatito lindo" width="300">
                </div>
            `;

            // D) Lo sumamos al contenedor sin borrar lo que ya existía
            miContenedor.innerHTML += tarjetaHTML;
        });

    } catch (error) {
        // Si algo falla (ej. te quedas sin internet), el flujo cae aquí
        console.error("Hubo un problema con la petición:", error);
    }
}

// Ejecutar la función al cargar la página
miFuncionAsincrona();


// 1. Seleccionamos el botón del HTML por su ID
const miBoton = document.getElementById("boton-recargar");

// 2. Le decimos que escuche el evento 'click'
miBoton.addEventListener("click", () => {
    // 3. Volvemos a llamar a la función para traer nuevos gatos
    miFuncionAsincrona();
});