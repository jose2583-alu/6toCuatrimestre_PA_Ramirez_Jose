<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $nombre           = trim($_POST["nombre"] ?? "");
    $apellido         = trim($_POST["apellido"] ?? "");
    $nacionalidad     = trim($_POST["nacionalidad"] ?? "");
    $fecha_nacimiento = trim($_POST["fecha_nacimiento"] ?? "") ?: null;

    if ($nombre === "" || $apellido === "") {
        header("Location: create.php?error=" . urlencode("El nombre y apellido son obligatorios"));
        exit;
    }

    // Aquí va el código para crear el autor usando una consulta preparada
    $stmt = $conn->prepare("INSERT INTO autores (nombre, apellido, nacionalidad, fecha_nacimiento) VALUES (?, ?, ?, ?)"); // $stmt es una variable que contiene nuestra consulta preparada. $conn->prepare() es un método que se utiliza para preparar una consulta SQL. Los signos de interrogación ? son los marcadores de posición, estos marcadores de posición serán reemplazados por los valores reales cuando ejecutemos la consulta.
    $stmt->bind_param("ssss", $nombre, $apellido, $nacionalidad, $fecha_nacimiento); // Aquí le pasamos los valores de los marcadores de posición a nuestra consulta previamente preparada. "ssss" indica el tipo de valor de los parámetros que voy a pasar a la consulta, para este ejemplo significa "string". $nombre, $apellido, $nacionalidad y $fecha_nacimiento son cuatro variables que contienen los valores que voy a insertar en mi base de datos.

    if ($stmt->execute()){ // Aquí ejecutamos la consulta preparada, si la ejecución es exitosa, redirigimos al usuario a la página de listado de autores con un mensaje de éxito
        header("Location: index.php?success=" . urlencode("Autor creado exitosamente"));
        exit;
    } else{
        header("Location: create.php?error=".urlencode("Error al crear el autor: " . $stmt->error));
        exit;
    }
    $stmt->close(); // Cerramos la consulta preparada
    $conn->close(); // Cerramos la conexión a la base de datos
?>
