<?php
include_once "../includes/header.php";
require_once "../config/connection.php"; //Importo la conexión a la base de datos

// Obtener usuarios
$stmt = $conn->prepare("
    SELECT id, nombre, apellido
    FROM usuarios
    ORDER BY nombre, apellido
");
$stmt->execute();
$result = $stmt->get_result();

$usuarios = [];

while ($row = $result->fetch_assoc()) {
    $usuarios[] = $row;
}

$stmt->close(); // Cerramos la consulta preparada para obtener usuarios

// Obtener libros
$stmt = $conn->prepare("
    SELECT id, titulo
    FROM libros
    ORDER BY titulo
");
$stmt->execute();
$result = $stmt->get_result();

$libros = [];

while ($row = $result->fetch_assoc()) {
    $libros[] = $row;
}

$stmt->close();
$conn->close(); // Cerramos la conexión a la base de datos
?>

<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nuevo Préstamo</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="save.php" method="POST">

        <div class="form-group">
            <label><i class="fas fa-user"></i> Usuario</label>
            <select name="id_usuario" required>
                <option value="">-- Selecciona un usuario --</option>

                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario['id']; ?>">
                        <?= htmlspecialchars($usuario['nombre'] . ' ' . $usuario['apellido']); ?>
                    </option>
                <?php endforeach; ?>

            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-book"></i> Libro</label>
            <select name="id_libro" required>
                <option value="">-- Selecciona un libro --</option>

                <?php foreach ($libros as $libro): ?>
                    <option value="<?= $libro['id']; ?>">
                        <?= htmlspecialchars($libro['titulo']); ?>
                    </option>
                <?php endforeach; ?>

            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Fecha de préstamo</label>
            <input type="date" name="fecha_prestamo" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar-check"></i> Fecha de devolución</label>
            <input type="date" name="fecha_devolucion" required>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>

            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>

    </form>
</div>

<?php include_once "../includes/footer.php"; ?>