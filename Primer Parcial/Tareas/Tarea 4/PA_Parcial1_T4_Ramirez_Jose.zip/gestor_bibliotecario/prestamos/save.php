<?php
require_once "../config/connection.php"; //Importo la conexión a la base de datos
if ($_SERVER["REQUEST_METHOD"] == "POST") { // Verificamos que la solicitud sea POST
    $id_usuario = intval($_POST['id_usuario'] ?? 0); // Obtenemos el ID del usuario y lo convertimos a entero, si no se proporciona se asigna 0
    $id_libro = intval($_POST['id_libro'] ?? 0); // Obtenemos el ID del libro y lo convertimos a entero, si no se proporciona se asigna 0
    $fecha_prestamo = $_POST['fecha_prestamo'] ?? ''; // Obtenemos la fecha de préstamo, si no se proporciona se asigna una cadena vacía
    $fecha_devolucion = $_POST['fecha_devolucion'] ?? ''; // Obtenemos la fecha de devolución, si no se proporciona se asigna una cadena vacía

    if ($id_usuario <= 0 || $id_libro <= 0 || $fecha_prestamo === '' || $fecha_devolucion === '') {
        header("Location: create.php?error=Todos los campos son obligatorios.");
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO prestamos (id_usuario, fecha_prestamo, fecha_devolucion) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $id_usuario, $fecha_prestamo, $fecha_devolucion);

    if ($stmt->execute()) {
        $id_prestamo = $stmt->insert_id;
        $stmt->close();

        // Insertar en detalle_prestamo
        $stmtDetalle = $conn->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro, cantidad) VALUES (?, ?, 1)");
        $stmtDetalle->bind_param("ii", $id_prestamo, $id_libro);

        if ($stmtDetalle->execute()) {
            $stmtDetalle->close();
            $conn->close();
            header("Location: index.php?success=Préstamo creado correctamente.");
            exit();
        } else {
            $stmtDetalle->close();
            $conn->close();
            header("Location: create.php?error=Error al crear el detalle del préstamo.");
            exit();
        }
    } else {
        header("Location: create.php?error=Error al crear el préstamo.");
        exit();
    }
} else {
    header("Location: index.php?error=Solicitud no válida.");
    exit();
}
?>
