<?php
    require_once "../config/connection.php";
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-user"></i> Préstamos</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Préstamo
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Usuario</th>
                <th>Fecha préstamo</th>
                <th>Fecha devolución</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Consulta para obtener los préstamos junto con el nombre del usuario
            $stmt = $conn->prepare("SELECT p.id, CONCAT(u.nombre, ' ', u.apellido) AS usuario, p.fecha_prestamo, p.fecha_devolucion, p.estado FROM prestamos p INNER JOIN usuarios u ON p.id_usuario = u.id");
            $stmt->execute();
            $result = $stmt->get_result();
        if ($result->num_rows > 0) {
             while($row = $result->fetch_assoc()) {
                 echo "<tr>";
                 echo "<td>" . $row["id"] . "</td>";
                 echo "<td>" . htmlspecialchars($row["usuario"]) . "</td>";
                 echo "<td>" . htmlspecialchars($row["fecha_prestamo"]) . "</td>";
                 echo "<td>" . htmlspecialchars($row["fecha_devolucion"]) . "</td>";
                 echo "<td>" . htmlspecialchars($row["estado"]) . "</td>";
                 echo "<td>";
                 echo "<a href='edit.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-warning'>Editar</a> ";
                 echo "<a href='delete.php?id=" . urlencode($row["id"]) . "' class='btn btn-sm btn-danger'>Eliminar</a>";
                 echo "</td>";
                 echo "</tr>";
        }
    } else {
      echo "<tr><td colspan='6'>No se encontraron préstamos.</td></tr>";
    }
      ?>
        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>