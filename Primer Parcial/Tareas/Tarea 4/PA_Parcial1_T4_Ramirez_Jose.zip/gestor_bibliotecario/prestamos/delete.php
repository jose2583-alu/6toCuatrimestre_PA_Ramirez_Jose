<?php
    require_once "../config/connection.php"; // Incluimos el archivo para la conexión a la base de datos.

    $id = intval($_GET["id"] ?? 0); // Obtenemos el ID del préstamo a eliminar desde la URL, y lo convertimos a un entero para mayor seguridad. Si no se proporciona un ID, se asigna 0.

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
   $stmt = $conn->prepare("DELETE FROM prestamos WHERE id = ?"); // Consulta preparada para eliminar el préstamo, tiene un marcador de posición para el ID.
    $stmt->bind_param("i", $id); // Vincula el ID a la consulta preparada, indicando que es un entero ("i").
    if($stmt->execute()){
        header("Location: index.php?success=" . urlencode("Préstamo eliminado con éxito."));
        exit;
    }else{
        header("Location: index.php?error=" . urlencode("Error al eliminar el préstamo: " . $stmt->error));
        exit;
    }
?>