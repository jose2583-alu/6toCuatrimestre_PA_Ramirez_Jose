<?php
require_once "../config/connection.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST['nombre'] ?? '');
    $apellido = trim($_POST['apellido'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $password = $_POST['password'] ?? '';
    $rol_id = intval($_POST['rol_id'] ?? 0);

    if ($nombre === '' || $apellido === '' || $correo === '' || $password === '' || $rol_id <= 0) {
        header("Location: create.php?error=Todos los campos son obligatorios.");
        exit();
    }

    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, id_rol) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $nombre, $apellido, $correo, $passwordHash, $rol_id);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        header("Location: index.php?success=Usuario creado correctamente.");
        exit();
    } else {
        $stmt->close();
        $conn->close();
        header("Location: create.php?error=Error al crear el usuario.");
        exit();
    }
} else {
    header("Location: index.php?error=Solicitud no válida.");
    exit();
}
?>
