<?php
require_once "../config/connection.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php?error=Solicitud no válida.");
    exit();
}

$id = intval($_POST['id'] ?? 0);
$nombre = trim($_POST['nombre'] ?? '');
$apellido = trim($_POST['apellido'] ?? '');
$correo = trim($_POST['correo'] ?? '');
$password = $_POST['password'] ?? '';

if ($id <= 0 || $nombre === '' || $apellido === '' || $correo === '') {
    header("Location: index.php?error=Datos incompletos.");
    exit();
}

// Verificar correo único diferente al usuario actual
$stmt = $conn->prepare("SELECT id FROM usuarios WHERE correo = ? AND id <> ?");
$stmt->bind_param("si", $correo, $id);
$stmt->execute();
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    $stmt->close();
    $conn->close();
    header("Location: edit.php?id={$id}&error=El correo ya está en uso por otro usuario.");
    exit();
}
$stmt->close();

if ($password !== '') {
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $nombre, $apellido, $correo, $password_hash, $id);
} else {
    $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ? WHERE id = ?");
    $stmt->bind_param("sssi", $nombre, $apellido, $correo, $id);
}

if ($stmt->execute()) {
    $stmt->close();
    $conn->close();
    header("Location: index.php?success=Usuario actualizado correctamente.");
    exit();
} else {
    $error = urlencode("Error al actualizar el usuario.");
    $stmt->close();
    $conn->close();
    header("Location: edit.php?id={$id}&error={$error}");
    exit();
}
?>
