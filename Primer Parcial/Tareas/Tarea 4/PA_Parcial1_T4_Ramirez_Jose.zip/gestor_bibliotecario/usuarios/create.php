<?php include_once "../includes/header.php";
require_once "../config/connection.php";
   $stmt = $conn->prepare("SELECT id, nombre FROM roles");
   $stmt->execute();
   $result = $stmt->get_result();
   $roles = [];
   while ($row = $result->fetch_assoc()) {
    $roles[] = $row;
   }
   $stmt->close(); // Cerramos la consulta preparada para liberar recursos
?>

<div class="page-header">
    <h1><i class="fas fa-plus-circle"></i> Nuevo Usuario</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="save.php" method="POST">
        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Nombre</label>
            <input type="text" name="nombre" placeholder="Ej: jose" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Apellido</label>
            <input type="text" name="apellido" placeholder="Ej: García" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Email</label>
            <input type="email" name="email" placeholder="Ej: jose@example.com" required>
        </div>
        <div class="form-group">
            <label><i class="fas fa-align-left"></i> Teléfono</label>
            <input type="text" name="telefono" placeholder="Ej: 123-456-7890" required>
        </div>

        <div class="form-group">
           <label><i class="fas fa-tag"></i> Rol</label>
           <select name="id_rol" required>
                <option value="">-- Selecciona un rol --</option>
              <?php foreach ($roles as $rol): ?>
                <option value="<?= $rol['id']; ?>">
                <?= htmlspecialchars($rol['nombre']); ?>
                </option>
              <?php endforeach; ?>
           </select>
       </div>
        
       <div class="form-group">
            <label><i class="fas fa-lock"></i> Contraseña</label>
            <input type="password" name="password" placeholder="Ej: ********" required>
        </div>


        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Guardar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
