<?php
    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    if ($id <= 0) {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }

    // Aquí va el código para eliminar el libro usando una consulta preparada
   $stmt = $conn->prepare("DELETE FROM libros WHERE id = ?"); // Consulta preparada para eliminar el libro, tiene un marcador de posición para el ID.
    $stmt->bind_param("i", $id); // Vincula el ID a la consulta preparada, indicando que es un entero ("i").
    if($stmt->execute()){
        header("Location: index.php?success=" . urlencode("Libro eliminado con éxito."));
        exit;
    }else{
        header("Location: index.php?error=" . urlencode("Error al eliminar el libro: " . $stmt->error));
        exit;
    }
?>