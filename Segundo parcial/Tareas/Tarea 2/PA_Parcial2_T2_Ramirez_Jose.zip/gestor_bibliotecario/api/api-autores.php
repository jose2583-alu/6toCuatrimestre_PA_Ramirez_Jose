<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Autor no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $nombre_param = "%$nombre%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE nombre LIKE ? ORDER BY id");
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();

            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }

            http_response_code(200);
            echo json_encode($autores);
            $stmt->close();
        } elseif (isset($_GET['nacionalidad'])) {
            $nacionalidad = trim($_GET['nacionalidad']);
            $nacionalidad_param = "%$nacionalidad%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE nacionalidad LIKE ? ORDER BY id");
            $stmt->bind_param("s", $nacionalidad_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();

            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }

            http_response_code(200);
            echo json_encode($autores);
            $stmt->close();
        } elseif (isset($_GET['apellido'])) {
            $apellido = trim($_GET['apellido']);
            $apellido_param = "%$apellido%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores WHERE apellido LIKE ? ORDER BY id");
            $stmt->bind_param("s", $apellido_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();

            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }

            http_response_code(200);
            echo json_encode($autores);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre, apellido, nacionalidad, fecha_nacimiento FROM autores ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $autores = array();

            while ($row = $resultado->fetch_assoc()) {
                $autores[] = $row;
            }

            http_response_code(200);
            echo json_encode($autores);
            $stmt->close();
        }
        $conn->close();
        break;
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? "");
        $apellido = trim($data['apellido'] ?? "");
        $nacionalidad = trim($data['nacionalidad'] ?? "");
        $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");
        
        if ($nombre === "" || $apellido === "") {
            http_response_code(400);
            echo json_encode(array("mensaje" => "el nombre y apellido son obligatorios"));
            $conn->close();
            break;
    }
    $fecha_nacimiento = $fecha_nacimiento !== "" ? $fecha_nacimiento : null;
    $stmt = $conn->prepare("INSERT INTO autores (nombre, apellido, nacionalidad, fecha_nacimiento) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nombre, $apellido, $nacionalidad, $fecha_nacimiento);
    
    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode(array("mensaje" => "Autor creado exitosamente", "id" => $stmt->insert_id));
        
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el autor " . $stmt->error));
            }
            $stmt->close();
            $conn->close();
            break;            
case 'PUT':
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un autor"));
        $conn->close();
        break;
    }
    $id = intval($_GET['id']);

    $check = $conn->prepare("SELECT id FROM autores WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(array("mensaje" => "Autor no encontrado"));
        $check->close();
        $conn->close();
        break;
    }
    $check->close();

    $data = json_decode(file_get_contents("php://input"), true);
    $nombre = trim($data['nombre'] ?? "");
    $apellido = trim($data['apellido'] ?? "");
    $nacionalidad = trim($data['nacionalidad'] ?? "");
    $fecha_nacimiento = trim($data['fecha_nacimiento'] ?? "");

    if ($nombre === "" || $apellido === "") {
        http_response_code(400);
        echo json_encode(array("mensaje" => "el nombre y apellido son obligatorios"));
        $conn->close();
        break;
    }
    $fecha_nacimiento = $fecha_nacimiento !== "" ? $fecha_nacimiento : null;

    $stmt = $conn->prepare("UPDATE autores SET nombre = ?, apellido = ?, nacionalidad = ?, fecha_nacimiento = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $nombre, $apellido, $nacionalidad, $fecha_nacimiento, $id);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Autor actualizado exitosamente"));
    } else {
        http_response_code(500);
        echo json_encode(array("mensaje" => "Error al actualizar el autor " . $stmt->error));
    }
    $stmt->close();
    $conn->close();
    break;
case 'PATCH':
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un autor"));
        $conn->close();
        break;
    }
    $id = intval($_GET['id']);

    $check = $conn->prepare("SELECT id FROM autores WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(array("mensaje" => "Autor no encontrado"));
        $check->close();
        $conn->close();
        break;
    }
    $check->close();

    $data = json_decode(file_get_contents("php://input"), true);
    $nombre = isset($data['nombre']) ? trim($data['nombre']) : null;
    $apellido = isset($data['apellido']) ? trim($data['apellido']) : null;
    $nacionalidad = isset($data['nacionalidad']) ? trim($data['nacionalidad']) : null;
    $fecha_nacimiento = isset($data['fecha_nacimiento']) ? trim($data['fecha_nacimiento']) : null;

    if ($nombre === null && $apellido === null && $nacionalidad === null && $fecha_nacimiento === null) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "Debes enviar al menos un campo para actualizar"));
        $conn->close();
        break;
    }

    $stmt = $conn->prepare("UPDATE autores SET nombre = COALESCE(NULLIF(?, ''), nombre), apellido = COALESCE(NULLIF(?, ''), apellido), nacionalidad = COALESCE(NULLIF(?, ''), nacionalidad), fecha_nacimiento = COALESCE(NULLIF(?, ''), fecha_nacimiento) WHERE id = ?");
    $stmt->bind_param("ssssi", $nombre, $apellido, $nacionalidad, $fecha_nacimiento, $id);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Autor actualizado exitosamente"));
    } else {
        http_response_code(500);
        echo json_encode(array("mensaje" => "Error al actualizar el autor " . $stmt->error));
    }
    $stmt->close();
    $conn->close();
    break;
case 'DELETE':
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "El id es obligatorio para eliminar un autor"));
        $conn->close();
        break;
    }
    $id = intval($_GET['id']);

    $check = $conn->prepare("SELECT id FROM autores WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(array("mensaje" => "Autor no encontrado"));
        $check->close();
        $conn->close();
        break;
    }
    $check->close();

    $stmt = $conn->prepare("DELETE FROM autores WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Autor eliminado exitosamente"));
    } else {
        http_response_code(500);
        echo json_encode(array("mensaje" => "Error al eliminar el autor " . $stmt->error));
    }
    $stmt->close();
    $conn->close();
    break;
    
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}