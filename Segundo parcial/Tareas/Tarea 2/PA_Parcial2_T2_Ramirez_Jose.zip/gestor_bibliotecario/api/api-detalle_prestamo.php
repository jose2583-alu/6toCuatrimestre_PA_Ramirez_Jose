<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Detalle de prestamo no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['prestamo'])) {
            $id_prestamo = intval($_GET['prestamo']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_prestamo = ? ORDER BY id");
            $stmt->bind_param("i", $id_prestamo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        } elseif (isset($_GET['libro'])) {
            $id_libro = intval($_GET['libro']);
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_libro = ? ORDER BY id");
            $stmt->bind_param("i", $id_libro);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        } elseif (isset($_GET['id_libro'])) {
            $id_libro = intval($_GET['id_libro']);
            $con_libro = isset($_GET['con_libro']) && strtolower(trim($_GET['con_libro'])) === 'true';

            if ($con_libro) {
                $stmt = $conn->prepare("SELECT detalle_prestamo.id, detalle_prestamo.id_prestamo, detalle_prestamo.id_libro, detalle_prestamo.cantidad, libros.titulo, libros.isbn FROM detalle_prestamo INNER JOIN libros ON detalle_prestamo.id_libro = libros.id WHERE detalle_prestamo.id_libro = ? ORDER BY detalle_prestamo.id");
            } else {
                $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo WHERE id_libro = ? ORDER BY id");
            }

            $stmt->bind_param("i", $id_libro);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, id_prestamo, id_libro, cantidad FROM detalle_prestamo ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $detalles = array();

            while ($row = $resultado->fetch_assoc()) {
                $detalles[] = $row;
            }

            http_response_code(200);
            echo json_encode($detalles);
            $stmt->close();
        }
        $conn->close();
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $id_prestamo = intval($data['id_prestamo'] ?? 0);
        $id_libro = intval($data['id_libro'] ?? 0);
        $cantidad = intval($data['cantidad'] ?? 0);

        if ($id_prestamo <= 0 || $id_libro <= 0 || $cantidad <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_prestamo, id_libro y cantidad son obligatorios y deben ser mayores a cero"));
            $conn->close();
            break;
        }

        $checkPrestamo = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $checkPrestamo->bind_param("i", $id_prestamo);
        $checkPrestamo->execute();
        if ($checkPrestamo->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_prestamo especificado no existe"));
            $checkPrestamo->close();
            $conn->close();
            break;
        }
        $checkPrestamo->close();

        $checkLibro = $conn->prepare("SELECT id FROM libros WHERE id = ?");
        $checkLibro->bind_param("i", $id_libro);
        $checkLibro->execute();
        if ($checkLibro->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_libro especificado no existe"));
            $checkLibro->close();
            $conn->close();
            break;
        }
        $checkLibro->close();

        $stmt = $conn->prepare("INSERT INTO detalle_prestamo (id_prestamo, id_libro, cantidad) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $id_prestamo, $id_libro, $cantidad);

        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Detalle de prestamo registrado exitosamente", "id" => $stmt->insert_id));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al registrar el detalle de prestamo: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'PUT':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un detalle de prestamo"));
            $conn->close();
            break;
        }
        $id = intval($_GET['id']);

        $check = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Detalle de prestamo no encontrado"));
            $check->close();
            $conn->close();
            break;
        }
        $check->close();

        $data = json_decode(file_get_contents("php://input"), true);
        $id_prestamo = intval($data['id_prestamo'] ?? 0);
        $id_libro = intval($data['id_libro'] ?? 0);
        $cantidad = intval($data['cantidad'] ?? 0);

        if ($id_prestamo <= 0 || $id_libro <= 0 || $cantidad <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Todos los campos son obligatorios y deben ser mayores a cero para la actualización completa"));
            $conn->close();
            break;
        }

        $checkPrestamo = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $checkPrestamo->bind_param("i", $id_prestamo);
        $checkPrestamo->execute();
        if ($checkPrestamo->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_prestamo especificado no existe"));
            $checkPrestamo->close();
            $conn->close();
            break;
        }
        $checkPrestamo->close();

        $checkLibro = $conn->prepare("SELECT id FROM libros WHERE id = ?");
        $checkLibro->bind_param("i", $id_libro);
        $checkLibro->execute();
        if ($checkLibro->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_libro especificado no existe"));
            $checkLibro->close();
            $conn->close();
            break;
        }
        $checkLibro->close();

        $stmt = $conn->prepare("UPDATE detalle_prestamo SET id_prestamo = ?, id_libro = ?, cantidad = ? WHERE id = ?");
        $stmt->bind_param("iiii", $id_prestamo, $id_libro, $cantidad, $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Detalle de prestamo actualizado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el detalle de prestamo: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'PATCH':
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un detalle de prestamo"));
        $conn->close();
        break;
    }
    $id = intval($_GET['id']);

    $check = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(array("mensaje" => "Detalle de prestamo no encontrado"));
        $check->close();
        $conn->close();
        break;
    }
    $check->close();

    $data = json_decode(file_get_contents("php://input"), true);
    $cantidad = isset($data['cantidad']) ? intval($data['cantidad']) : null;

    if ($cantidad === null || $cantidad <= 0) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "La cantidad es obligatoria y debe ser mayor a cero"));
        $conn->close();
        break;
    }

    $stmt = $conn->prepare("UPDATE detalle_prestamo SET cantidad = ? WHERE id = ?");
    $stmt->bind_param("ii", $cantidad, $id);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Cantidad actualizada exitosamente"));
    } else {
        http_response_code(500);
        echo json_encode(array("mensaje" => "Error al actualizar la cantidad: " . $stmt->error));
    }
    $stmt->close();
    $conn->close();
    break;
    case 'DELETE':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar un detalle de prestamo"));
            $conn->close();
            break;
        }
        $id = intval($_GET['id']);

        $check = $conn->prepare("SELECT id FROM detalle_prestamo WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Detalle de prestamo no encontrado"));
            $check->close();
            $conn->close();
            break;
        }
        $check->close();

        $stmt = $conn->prepare("DELETE FROM detalle_prestamo WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Detalle de prestamo eliminado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al eliminar el detalle de prestamo: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}