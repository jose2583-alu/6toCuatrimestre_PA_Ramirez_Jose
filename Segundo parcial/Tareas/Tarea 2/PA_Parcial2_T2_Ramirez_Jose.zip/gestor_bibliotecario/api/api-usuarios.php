<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Usuario no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $nombre_param = "%$nombre%";
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE nombre LIKE ? ORDER BY id");
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } elseif (isset($_GET['correo'])) {
            $correo = trim($_GET['correo']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE correo = ? ORDER BY id");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } elseif (isset($_GET['id_rol'])) {
            $id_rol = intval($_GET['id_rol']);
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios WHERE id_rol = ? ORDER BY id");
            $stmt->bind_param("i", $id_rol);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre, apellido, correo, telefono, id_rol, activo, fecha_registro FROM usuarios ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $usuarios = array();

            while ($row = $resultado->fetch_assoc()) {
                $usuarios[] = $row;
            }

            http_response_code(200);
            echo json_encode($usuarios);
            $stmt->close();
        }
        $conn->close();
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? "");
        $apellido = trim($data['apellido'] ?? "");
        $correo = trim($data['correo'] ?? "");
        $password = trim($data['password'] ?? "");
        $telefono = trim($data['telefono'] ?? "");
        $id_rol = intval($data['id_rol'] ?? 0);
        $activo = isset($data['activo']) ? intval($data['activo']) : 1;
        
        if ($nombre === "" || $apellido === "" || $correo === "" || $password === "") {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre, apellido, correo y contraseña son obligatorios"));
            $conn->close();
            break;
        }

        $checkRol = $conn->prepare("SELECT id FROM roles WHERE id = ?");
        $checkRol->bind_param("i", $id_rol);
        $checkRol->execute();
        if ($checkRol->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_rol especificado no existe"));
            $checkRol->close();
            $conn->close();
            break;
        }
        $checkRol->close();

        $stmt = $conn->prepare("INSERT INTO usuarios (nombre, apellido, correo, password, telefono, id_rol, activo) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo);

        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Usuario creado exitosamente", "id" => $stmt->insert_id));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el usuario: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;                  

    case 'PUT':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un usuario"));
            $conn->close();
            break;
        }
        $id = intval($_GET['id']);

        $check = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Usuario no encontrado"));
            $check->close();
            $conn->close();
            break;
        }
        $check->close();

        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? "");
        $apellido = trim($data['apellido'] ?? "");
        $correo = trim($data['correo'] ?? "");
        $password = trim($data['password'] ?? "");
        $telefono = trim($data['telefono'] ?? "");
        $id_rol = intval($data['id_rol'] ?? 0);
        $activo = isset($data['activo']) ? intval($data['activo']) : 1;

        if ($nombre === "" || $apellido === "" || $correo === "" || $password === "") {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre, apellido, correo y contraseña son obligatorios"));
            $conn->close();
            break;
        }

        $checkRol = $conn->prepare("SELECT id FROM roles WHERE id = ?");
        $checkRol->bind_param("i", $id_rol);
        $checkRol->execute();
        if ($checkRol->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_rol especificado no existe"));
            $checkRol->close();
            $conn->close();
            break;
        }
        $checkRol->close();

        $stmt = $conn->prepare("UPDATE usuarios SET nombre = ?, apellido = ?, correo = ?, password = ?, telefono = ?, id_rol = ?, activo = ? WHERE id = ?");
        $stmt->bind_param("sssssiii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo, $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Usuario actualizado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el usuario: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'PATCH':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un usuario"));
            $conn->close();
            break;
        }
        $id = intval($_GET['id']);

        $check = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Usuario no encontrado"));
            $check->close();
            $conn->close();
            break;
        }
        $check->close();

        $data = json_decode(file_get_contents("php://input"), true);
        
        $nombre = isset($data['nombre']) ? trim($data['nombre']) : null;
        $apellido = isset($data['apellido']) ? trim($data['apellido']) : null;
        $correo = isset($data['correo']) ? trim($data['correo']) : null;
        $password = isset($data['password']) ? trim($data['password']) : null;
        $telefono = isset($data['telefono']) ? trim($data['telefono']) : null;
        $id_rol = isset($data['id_rol']) ? intval($data['id_rol']) : null;
        $activo = isset($data['activo']) ? intval($data['activo']) : null;

        if ($nombre === null && $apellido === null && $correo === null && $password === null && $telefono === null && $id_rol === null && $activo === null) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Debes enviar al menos un campo para actualizar"));
            $conn->close();
            break;
        }

        $stmt = $conn->prepare("UPDATE usuarios SET 
            nombre = COALESCE(?, nombre), 
            apellido = COALESCE(?, apellido), 
            correo = COALESCE(?, correo), 
            password = COALESCE(?, password), 
            telefono = COALESCE(?, telefono), 
            id_rol = COALESCE(?, id_rol), 
            activo = COALESCE(?, activo) 
            WHERE id = ?");
            
        $stmt->bind_param("sssssiii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $activo, $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Usuario actualizado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el usuario: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar un usuario"));
            $conn->close();
            break;
        }
        $id = intval($_GET['id']);

        $check = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Usuario no encontrado"));
            $check->close();
            $conn->close();
            break;
        }
        $check->close();

        $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Usuario eliminado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al eliminar el usuario: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;
        
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}