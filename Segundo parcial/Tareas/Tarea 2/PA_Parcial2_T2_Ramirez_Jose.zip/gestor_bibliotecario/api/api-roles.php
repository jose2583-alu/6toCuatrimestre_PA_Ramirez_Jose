<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre FROM roles WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Rol no encontrado"));
            }
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre FROM roles ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $roles = array();

            while ($row = $resultado->fetch_assoc()) {
                $roles[] = $row;
            }

            http_response_code(200);
            echo json_encode($roles);
            $stmt->close();
        }
        $conn->close();
        break;
   case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? "");
        
        if ($nombre === "") {
            http_response_code(400);
            echo json_encode(array("mensaje" => "el nombre es obligatorio"));
            $conn->close();
            break;
    }
    $stmt = $conn->prepare("INSERT INTO roles (nombre) VALUES (?)");
    $stmt->bind_param("s", $nombre);
    
    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode(array("mensaje" => "Rol creado exitosamente", "id" => $stmt->insert_id));
        
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el rol " . $stmt->error));
            }
            $stmt->close();
            $conn->close();
            break;            
case 'PUT':
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un rol"));
        $conn->close();
        break;
    }
    $id = intval($_GET['id']);

    $check = $conn->prepare("SELECT id FROM roles WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(array("mensaje" => "Rol no encontrado"));
        $check->close();
        $conn->close();
        break;
    }
    $check->close();

    $data = json_decode(file_get_contents("php://input"), true);
    $nombre = trim($data['nombre'] ?? "");

    if ($nombre === "") {
        http_response_code(400);
        echo json_encode(array("mensaje" => "el nombre es obligatorio"));
        $conn->close();
        break;
    }

    $stmt = $conn->prepare("UPDATE roles SET nombre = ? WHERE id = ?");
    $stmt->bind_param("si", $nombre, $id);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Rol actualizado exitosamente"));
    } else {
        http_response_code(500);
        echo json_encode(array("mensaje" => "Error al actualizar el rol " . $stmt->error));
    }
    $stmt->close();
    $conn->close();
    break;
case 'PATCH':
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un rol"));
        $conn->close();
        break;
    }
    $id = intval($_GET['id']);

    $check = $conn->prepare("SELECT id FROM roles WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(array("mensaje" => "Rol no encontrado"));
        $check->close();
        $conn->close();
        break;
    }
    $check->close();

    $data = json_decode(file_get_contents("php://input"), true);
    $nombre = isset($data['nombre']) ? trim($data['nombre']) : null;

    if ($nombre === null) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "El nombre es un campo obligatorio"));
        $conn->close();
        break;
    }

    $stmt = $conn->prepare("UPDATE roles SET nombre = COALESCE(NULLIF(?, ''), nombre) WHERE id = ?");
    $stmt->bind_param("si", $nombre, $id);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Rol actualizado exitosamente"));
    } else {
        http_response_code(500);
        echo json_encode(array("mensaje" => "Error al actualizar el rol " . $stmt->error));
    }
    $stmt->close();
    $conn->close();
    break;
case 'DELETE':
    if (!isset($_GET['id'])) {
        http_response_code(400);
        echo json_encode(array("mensaje" => "El id es obligatorio para eliminar un rol"));
        $conn->close();
        break;
    }
    $id = intval($_GET['id']);

    $check = $conn->prepare("SELECT id FROM roles WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    if ($check->get_result()->num_rows === 0) {
        http_response_code(404);
        echo json_encode(array("mensaje" => "Rol no encontrado"));
        $check->close();
        $conn->close();
        break;
    }
    $check->close();

    $stmt = $conn->prepare("DELETE FROM roles WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(array("mensaje" => "Rol eliminado exitosamente"));
    } else {
        http_response_code(500);
        echo json_encode(array("mensaje" => "Error al eliminar el rol " . $stmt->error));
    }
    $stmt->close();
    $conn->close();
    break;
    
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}