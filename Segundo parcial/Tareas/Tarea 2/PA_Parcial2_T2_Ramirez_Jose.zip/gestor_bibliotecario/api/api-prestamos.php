<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Prestamo no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['usuario'])) {
            $usuario = trim($_GET['usuario']);
            $usuario_param = "%$usuario%";
            $stmt = $conn->prepare("SELECT prestamos.id, prestamos.id_usuario, usuarios.nombre, usuarios.apellido, prestamos.fecha_prestamo, prestamos.fecha_devolucion, prestamos.estado FROM prestamos INNER JOIN usuarios ON prestamos.id_usuario = usuarios.id WHERE usuarios.nombre LIKE ? OR usuarios.apellido LIKE ? ORDER BY prestamos.id");
            $stmt->bind_param("ss", $usuario_param, $usuario_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        } elseif (isset($_GET['estado'])) {
            $estado = trim($_GET['estado']);
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE estado = ? ORDER BY id");
            $stmt->bind_param("s", $estado);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        } elseif (isset($_GET['atrasados']) && strtolower(trim($_GET['atrasados'])) === 'true') {
            $estado_no_devuelto = 'devuelto';
            $hoy = date('Y-m-d');
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos WHERE fecha_devolucion < ? AND estado <> ? ORDER BY id");
            $stmt->bind_param("ss", $hoy, $estado_no_devuelto);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, id_usuario, fecha_prestamo, fecha_devolucion, estado FROM prestamos ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $prestamos = array();

            while ($row = $resultado->fetch_assoc()) {
                $prestamos[] = $row;
            }

            http_response_code(200);
            echo json_encode($prestamos);
            $stmt->close();
        }
        $conn->close();
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $id_usuario = intval($data['id_usuario'] ?? 0);
        $fecha_prestamo = trim($data['fecha_prestamo'] ?? "");
        $fecha_devolucion = trim($data['fecha_devolucion'] ?? "");
        $estado = trim($data['estado'] ?? "prestado");

        if ($id_usuario <= 0 || $fecha_prestamo === "" || $fecha_devolucion === "") {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_usuario, fecha_prestamo y fecha_devolucion son obligatorios"));
            $conn->close();
            break;
        }

        if ($fecha_devolucion < $fecha_prestamo) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "La fecha de devolución no puede ser anterior a la fecha de préstamo"));
            $conn->close();
            break;
        }

        $estados_validos = ['prestado', 'devuelto', 'retrasado'];
        if (!in_array($estado, $estados_validos)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El estado debe ser: prestado, devuelto o retrasado"));
            $conn->close();
            break;
        }

        $checkUsuario = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $checkUsuario->bind_param("i", $id_usuario);
        $checkUsuario->execute();
        if ($checkUsuario->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_usuario指定 no existe"));
            $checkUsuario->close();
            $conn->close();
            break;
        }
        $checkUsuario->close();

        $stmt = $conn->prepare("INSERT INTO prestamos (id_usuario, fecha_prestamo, fecha_devolucion, estado) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado);

        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Prestamo registrado exitosamente", "id" => $stmt->insert_id));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al registrar el prestamo: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'PUT':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un prestamo"));
            $conn->close();
            break;
        }
        $id = intval($_GET['id']);

        $check = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Prestamo no encontrado"));
            $check->close();
            $conn->close();
            break;
        }
        $check->close();

        $data = json_decode(file_get_contents("php://input"), true);
        $id_usuario = intval($data['id_usuario'] ?? 0);
        $fecha_prestamo = trim($data['fecha_prestamo'] ?? "");
        $fecha_devolucion = trim($data['fecha_devolucion'] ?? "");
        $estado = trim($data['estado'] ?? "");

        if ($id_usuario <= 0 || $fecha_prestamo === "" || $fecha_devolucion === "" || $estado === "") {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Todos los campos son obligatorios para la actualización completa"));
            $conn->close();
            break;
        }

        if ($fecha_devolucion < $fecha_prestamo) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "La fecha de devolución no puede ser anterior a la fecha de préstamo"));
            $conn->close();
            break;
        }

        $estados_validos = ['prestado', 'devuelto', 'retrasado'];
        if (!in_array($estado, $estados_validos)) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El estado debe ser: prestado, devuelto o retrasado"));
            $conn->close();
            break;
        }

        $checkUsuario = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
        $checkUsuario->bind_param("i", $id_usuario);
        $checkUsuario->execute();
        if ($checkUsuario->get_result()->num_rows === 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id_usuario especificado no existe"));
            $checkUsuario->close();
            $conn->close();
            break;
        }
        $checkUsuario->close();

        $stmt = $conn->prepare("UPDATE prestamos SET id_usuario = ?, fecha_prestamo = ?, fecha_devolucion = ?, estado = ? WHERE id = ?");
        $stmt->bind_param("isssi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Prestamo actualizado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el prestamo: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'PATCH':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un prestamo"));
            $conn->close();
            break;
        }
        $id = intval($_GET['id']);

        $check = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Prestamo no encontrado"));
            $check->close();
            $conn->close();
            break;
        }
        $check->close();

        $data = json_decode(file_get_contents("php://input"), true);

        $id_usuario = isset($data['id_usuario']) ? intval($data['id_usuario']) : null;
        $fecha_prestamo = isset($data['fecha_prestamo']) ? trim($data['fecha_prestamo']) : null;
        $fecha_devolucion = isset($data['fecha_devolucion']) ? trim($data['fecha_devolucion']) : null;
        $estado = isset($data['estado']) ? trim($data['estado']) : null;

        if ($id_usuario === null && $fecha_prestamo === null && $fecha_devolucion === null && $estado === null) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Debes enviar al menos un campo para actualizar"));
            $conn->close();
            break;
        }

        if (($fecha_prestamo !== null || $fecha_devolucion !== null)) {
            $stmtFechas = $conn->prepare("SELECT fecha_prestamo, fecha_devolucion FROM prestamos WHERE id = ?");
            $stmtFechas->bind_param("i", $id);
            $stmtFechas->execute();
            $resFechas = $stmtFechas->get_result()->fetch_assoc();
            $stmtFechas->close();

            $f_prestamo_eval = $fecha_prestamo !== null ? $fecha_prestamo : $resFechas['fecha_prestamo'];
            $f_devolucion_eval = $fecha_devolucion !== null ? $fecha_devolucion : $resFechas['fecha_devolucion'];

            if ($f_devolucion_eval < $f_prestamo_eval) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "La fecha de devolución no puede ser anterior a la fecha de préstamo"));
                $conn->close();
                break;
            }
        }

        if ($estado !== null) {
            $estados_validos = ['prestado', 'devuelto', 'retrasado'];
            if (!in_array($estado, $estados_validos)) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El estado debe ser: prestado, devuelto o retrasado"));
                $conn->close();
                break;
            }
        }

        if ($id_usuario !== null) {
            $checkUsuario = $conn->prepare("SELECT id FROM usuarios WHERE id = ?");
            $checkUsuario->bind_param("i", $id_usuario);
            $checkUsuario->execute();
            if ($checkUsuario->get_result()->num_rows === 0) {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El id_usuario especificado no existe"));
                $checkUsuario->close();
                $conn->close();
                break;
            }
            $checkUsuario->close();
        }

        $stmt = $conn->prepare("UPDATE prestamos SET 
            id_usuario = COALESCE(?, id_usuario), 
            fecha_prestamo = COALESCE(?, fecha_prestamo), 
            fecha_devolucion = COALESCE(?, fecha_devolucion), 
            estado = COALESCE(?, estado) 
            WHERE id = ?");
            
        $stmt->bind_param("isssi", $id_usuario, $fecha_prestamo, $fecha_devolucion, $estado, $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Prestamo modificado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el prestamo: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar un prestamo"));
            $conn->close();
            break;
        }
        $id = intval($_GET['id']);

        $check = $conn->prepare("SELECT id FROM prestamos WHERE id = ?");
        $check->bind_param("i", $id);
        $check->execute();
        if ($check->get_result()->num_rows === 0) {
            http_response_code(404);
            echo json_encode(array("mensaje" => "Prestamo no encontrado"));
            $check->close();
            $conn->close();
            break;
        }
        $check->close();

        $stmt = $conn->prepare("DELETE FROM prestamos WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Prestamo eliminado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al eliminar el prestamo: " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}