<?php
    require_once "../config/connection.php";

    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        header("Location: index.php");
        exit;
    }

    $id = intval($_POST["id"] ?? 0);
    $nombre = trim($_POST["nombre"] ?? "");
    $apellido = trim($_POST["apellido"] ?? "");
    $correo = trim($_POST["correo"] ?? "");
    $password = trim($_POST["password"] ?? "");
    $telefono = trim($_POST["telefono"] ?? "");
    $id_rol = intval($_POST["id_rol"] ?? 0);

    if ($id <= 0 || $nombre === "" || $apellido === "") {
        header("Location: index.php?error=" . urlencode("Datos inválidos"));
        exit;
    }

    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        header("Location: edit.php?id=" . urlencode($id) . "&error=" . urlencode("El correo no es válido"));
        exit;
    }

    if (strlen($password) < 6) {
        header("Location: edit.php?id=" . urlencode($id) . "&error=" . urlencode("La contraseña debe tener al menos 6 caracteres"));
        exit;
    }

    if ($id_rol <= 0) {
        header("Location: edit.php?id=" . urlencode($id) . "&error=" . urlencode("El rol es obligatorio"));
        exit;
    }

    // Aquí va el código para actualizar el usuario usando una consulta preparada
    $stmt = $conn->prepare("UPDATE usuarios SET nombre=?, apellido=?, correo=?, password=?, telefono=?, id_rol=? WHERE id = ?");
    $stmt->bind_param("sssssii", $nombre, $apellido, $correo, $password, $telefono, $id_rol, $id);

    if ($stmt->execute()) {
        header("Location: index.php?success=" . urlencode("Usuario actualizado exitosamente"));
        exit;
    } else {
        header("Location: edit.php?id=" . urlencode($id) . "&error=" . urlencode("Error al actualizar el usuario: " . $stmt->error));
        exit;
    }
    $stmt->close();
    $conn->close();
?>