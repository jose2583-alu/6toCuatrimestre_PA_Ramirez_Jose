<?php
require_once('../config/connection.php');
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"), JSON_UNESCAPED_UNICODE);
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();
            if ($resultado->num_rows > 0) {
                $categoria = $resultado->fetch_assoc();
                http_response_code(200);
                echo json_encode($categoria, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Categoría no encontrada"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['todas']) && strtolower(trim($_GET['todas'])) === 'true') {
            $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $categorias = array();
            while ($row = $resultado->fetch_assoc()) {
                $categorias[] = $row;
            }
            http_response_code(200);
            echo json_encode($categorias, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        } elseif (isset($_GET['nombre'])) {
            $nombre = trim($_GET['nombre']);
            $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias WHERE nombre LIKE ?");
            $nombre_param = "%$nombre%";
            $stmt->bind_param("s", $nombre_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $categorias = array();
            if ($resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    $categorias[] = $row;
                }
                http_response_code(200);
                echo json_encode($categorias, JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Categoría no encontrada"), JSON_UNESCAPED_UNICODE);
            }
            $stmt->close();
            $conn->close();
        } else {
            $stmt = $conn->prepare("SELECT id, nombre, descripcion FROM categorias ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $categorias = array();
            while ($row = $resultado->fetch_assoc()) {
                $categorias[] = $row;
            }
            http_response_code(200);
            echo json_encode($categorias, JSON_UNESCAPED_UNICODE);
            $stmt->close();
            $conn->close();
        }
        break;
    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $nombre = trim($data['nombre'] ?? "");
        $descripcion = trim($data['descripcion'] ?? "");
        if (!empty($nombre)) {
            $stmt = $conn->prepare("INSERT INTO categorias (nombre, descripcion) VALUES (?, ?)");
            $stmt->bind_param("ss", $nombre, $descripcion);
            if ($stmt->execute()) {
                http_response_code(201);
                echo json_encode(array("mensaje" => "Categoría creada exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al crear la categoría: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El nombre es obligatorio"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'PUT':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $nombre = trim($data['nombre'] ?? "");
            $descripcion = trim($data['descripcion'] ?? "");
            if (!empty($nombre)) {
                $stmt = $conn->prepare("UPDATE categorias SET nombre = ?, descripcion = ? WHERE id = ?");
                $stmt->bind_param("ssi", $nombre, $descripcion, $id);
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Categoría actualizada exitosamente"), JSON_UNESCAPED_UNICODE);
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar la categoría: " . $stmt->error), JSON_UNESCAPED_UNICODE);
                }
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "El nombre es un campo obligatorio"), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar una categoría"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'PATCH':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $data = json_decode(file_get_contents("php://input"), true);
            $nombre = trim($data['nombre'] ?? "");
            $descripcion = trim($data['descripcion'] ?? "");
            if (!empty($nombre) || !empty($descripcion)) {
                $stmt = $conn->prepare("UPDATE categorias SET nombre = COALESCE(NULLIF(?, ''), nombre), descripcion = COALESCE(NULLIF(?, ''), descripcion) WHERE id = ?");
                $stmt->bind_param("ssi", $nombre, $descripcion, $id);
                if ($stmt->execute()) {
                    http_response_code(200);
                    echo json_encode(array("mensaje" => "Categoría actualizada exitosamente"), JSON_UNESCAPED_UNICODE);
                } else {
                    http_response_code(500);
                    echo json_encode(array("mensaje" => "Error al actualizar la categoría: " . $stmt->error), JSON_UNESCAPED_UNICODE);
                }
            } else {
                http_response_code(400);
                echo json_encode(array("mensaje" => "Al menos un campo es obligatorio para actualizar la categoría"), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar una categoría"), JSON_UNESCAPED_UNICODE);
        }
        break;
    case 'DELETE':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("DELETE FROM categorias WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                http_response_code(200);
                echo json_encode(array("mensaje" => "Categoría eliminada exitosamente"), JSON_UNESCAPED_UNICODE);
            } else {
                http_response_code(500);
                echo json_encode(array("mensaje" => "Error al eliminar la categoría: " . $stmt->error), JSON_UNESCAPED_UNICODE);
            }
        } else {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar una categoría"), JSON_UNESCAPED_UNICODE);
        }
        break;
    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Método no permitido"), JSON_UNESCAPED_UNICODE);
        break;
}
