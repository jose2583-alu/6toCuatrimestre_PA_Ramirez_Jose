<?php
require_once('../config/connection.php');

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'OPTIONS') {
    http_response_code(200);
    echo json_encode(array("mensaje" => "Preflight OK"));
    $conn->close();
    exit;
}

switch ($method) {
    case 'GET':
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']);
            $stmt = $conn->prepare("SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria, fecha_registro FROM libros WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows > 0) {
                http_response_code(200);
                echo json_encode($resultado->fetch_assoc());
            } else {
                http_response_code(404);
                echo json_encode(array("mensaje" => "Libro no encontrado"));
            }
            $stmt->close();
        } elseif (isset($_GET['titulo'])) {
            $titulo = trim($_GET['titulo']);
            $titulo_param = "%$titulo%";
            $stmt = $conn->prepare("SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria, fecha_registro FROM libros WHERE titulo LIKE ? ORDER BY id");
            $stmt->bind_param("s", $titulo_param);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();

            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }

            http_response_code(200);
            echo json_encode($libros);
            $stmt->close();
        } elseif (isset($_GET['anio'])) {
            $anio = intval($_GET['anio']);
            $stmt = $conn->prepare("SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria, fecha_registro FROM libros WHERE anio_publicacion = ? ORDER BY id");
            $stmt->bind_param("i", $anio);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();

            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }

            http_response_code(200);
            echo json_encode($libros);
            $stmt->close();
        } elseif (isset($_GET['isbn'])) {
            $isbn = trim($_GET['isbn']);
            $stmt = $conn->prepare("SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria, fecha_registro FROM libros WHERE isbn = ? ORDER BY id");
            $stmt->bind_param("s", $isbn);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();

            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }

            http_response_code(200);
            echo json_encode($libros);
            $stmt->close();
        } else {
            $stmt = $conn->prepare("SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria, fecha_registro FROM libros ORDER BY id");
            $stmt->execute();
            $resultado = $stmt->get_result();
            $libros = array();

            while ($row = $resultado->fetch_assoc()) {
                $libros[] = $row;
            }

            http_response_code(200);
            echo json_encode($libros);
            $stmt->close();
        }
        $conn->close();
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"), true);
        $titulo = trim($data['titulo'] ?? "");
        $isbn = trim($data['isbn'] ?? "");
        $anio_publicacion = intval($data['anio_publicacion'] ?? 0);
        $editorial = trim($data['editorial'] ?? "");
        $cantidad = intval($data['cantidad'] ?? 0);
        $disponibles = intval($data['disponibles'] ?? 0);
        $id_categoria = intval($data['id_categoria'] ?? 0);

        if ($titulo === "" || $isbn === "" || $id_categoria <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "titulo, isbn e id_categoria son obligatorios"));
            $conn->close();
            break;
        }

        $stmt = $conn->prepare("INSERT INTO libros (titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssisiii", $titulo, $isbn, $anio_publicacion, $editorial, $cantidad, $disponibles, $id_categoria);

        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(array("mensaje" => "Libro creado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al crear el libro " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'PUT':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un libro"));
            $conn->close();
            break;
        }

        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);
        $titulo = trim($data['titulo'] ?? "");
        $isbn = trim($data['isbn'] ?? "");
        $anio_publicacion = intval($data['anio_publicacion'] ?? 0);
        $editorial = trim($data['editorial'] ?? "");
        $cantidad = intval($data['cantidad'] ?? 0);
        $disponibles = intval($data['disponibles'] ?? 0);
        $id_categoria = intval($data['id_categoria'] ?? 0);

        if ($titulo === "" || $isbn === "" || $id_categoria <= 0) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "titulo, isbn e id_categoria son obligatorios"));
            $conn->close();
            break;
        }

        $stmt = $conn->prepare("UPDATE libros SET titulo = ?, isbn = ?, anio_publicacion = ?, editorial = ?, cantidad = ?, disponibles = ?, id_categoria = ? WHERE id = ?");
        $stmt->bind_param("ssisiiii", $titulo, $isbn, $anio_publicacion, $editorial, $cantidad, $disponibles, $id_categoria, $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Libro actualizado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el libro " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'PATCH':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para actualizar un libro"));
            $conn->close();
            break;
        }

        $id = intval($_GET['id']);
        $data = json_decode(file_get_contents("php://input"), true);

        $titulo = isset($data['titulo']) ? trim($data['titulo']) : null;
        $isbn = isset($data['isbn']) ? trim($data['isbn']) : null;
        $anio_publicacion = isset($data['anio_publicacion']) ? intval($data['anio_publicacion']) : null;
        $editorial = isset($data['editorial']) ? trim($data['editorial']) : null;
        $cantidad = isset($data['cantidad']) ? intval($data['cantidad']) : null;
        $disponibles = isset($data['disponibles']) ? intval($data['disponibles']) : null;
        $id_categoria = isset($data['id_categoria']) ? intval($data['id_categoria']) : null;

        if ($titulo === null && $isbn === null && $anio_publicacion === null && $editorial === null && $cantidad === null && $disponibles === null && $id_categoria === null) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "Debes enviar al menos un campo para actualizar"));
            $conn->close();
            break;
        }

        $stmt = $conn->prepare("UPDATE libros SET titulo = COALESCE(NULLIF(?, ''), titulo), isbn = COALESCE(NULLIF(?, ''), isbn), anio_publicacion = COALESCE(?, anio_publicacion), editorial = COALESCE(NULLIF(?, ''), editorial), cantidad = COALESCE(?, cantidad), disponibles = COALESCE(?, disponibles), id_categoria = COALESCE(?, id_categoria) WHERE id = ?");
        $stmt->bind_param("ssisiiii", $titulo, $isbn, $anio_publicacion, $editorial, $cantidad, $disponibles, $id_categoria, $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Libro actualizado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al actualizar el libro " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    case 'DELETE':
        if (!isset($_GET['id'])) {
            http_response_code(400);
            echo json_encode(array("mensaje" => "El id es obligatorio para eliminar un libro"));
            $conn->close();
            break;
        }

        $id = intval($_GET['id']);
        $stmt = $conn->prepare("DELETE FROM libros WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(array("mensaje" => "Libro eliminado exitosamente"));
        } else {
            http_response_code(500);
            echo json_encode(array("mensaje" => "Error al eliminar el libro " . $stmt->error));
        }
        $stmt->close();
        $conn->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(array("mensaje" => "Metodo no permitido"));
        $conn->close();
        break;
}
